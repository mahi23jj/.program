# .program
empty program
not a malware
it not used as a c#/C++/C
the .program.exe romval is a .program uninstaller
this bat file uses idk.vbs
to uninstall .program.exe your username need to be called:solom 
good luck